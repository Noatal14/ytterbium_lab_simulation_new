"""Publication-only recovery. Original runtime and RNG provenance stay immutable."""
import runpy, inspect, json, shlex, shutil, hashlib
from pathlib import Path
import numpy as np

runtime = Path('/home/tal.noa/ytterbium_validation_runtime_5us_50ms_20261019_v1')
repo = Path('/home/tal.noa/ytterbium_lab_simulation_new')
root = repo/'data/optimization/mot_3d/mot_3d_s0_1p3_search10us_20261012_v1'
runpy.run_path(str(runtime/'entry.py'), run_name='recovery_bootstrap')
from studies.mot_3d import final_validation as fv, checkpoint_validation as cp

def forbidden(*args, **kwargs):
    raise RuntimeError('Recovery must never integrate an atom; checkpoint missing')
cp.run_compact_validation = forbidden
fv.run_compact_validation = forbidden
source = inspect.getsource(fv.run)
assert source.count('eligible_at_100ms') == 1
exec(compile(source.replace('eligible_at_100ms','eligible_at_50ms'), '<publication-only-endpoint-fix>', 'exec'), fv.__dict__)
original_validator = fv.validate_completed_result
backup = root/'diagnostics/publication_recovery_20261020'
backup.mkdir(exist_ok=True)
audit = []
for family in ('angled_donut','single_pass'):
    for seed in (44001,44002,44003):
        script = runtime/'jobs'/f'{family}_{seed}_attempt3.pbs'
        command = next(line for line in script.read_text().splitlines() if line.startswith('python -u '))
        argv = shlex.split(command)[3:]
        args = fv.parse_args(argv)
        output = Path(args.output)
        archive = output.with_suffix('.npz')
        states, ids, _ = fv.load_sealed_inputs(args.input_manifest,args.campaign_manifest,args.locked_nominals)
        locked = json.loads(Path(args.locked_nominals).read_text())
        end, ever, flags = cp.run_checkpointed_validation(states, checkpoint_dir=args.checkpoint_dir,
            chunk_size=args.checkpoint_chunk_size, profile=locked['families'][family]['resolved_profile'],
            seed=seed, npools=0, dt=args.dt, t_max=args.t_max, collect_comparison=True)
        assert len(end)==16675
        if archive.exists():
            with np.load(archive,allow_pickle=False) as data:
                for key, expected in [('usable_at_end',end),('usable_ever',ever),('ensemble_ids',ids)]:
                    np.testing.assert_array_equal(data[key],expected)
            target = backup/f'{family}_{seed}.npz'
            if not target.exists(): shutil.copy2(archive,target)
        def checked_partial(j,n,**kwargs):
            if Path(j)==output and not output.exists() and archive.exists():
                return False  # Existing archive was compared to every validated checkpoint above.
            return original_validator(j,n,**kwargs)
        fv.validate_completed_result=checked_partial
        fv.run(args)
        fv.validate_completed_result=original_validator
        assert original_validator(output,archive,kind='mot_3d_sealed_final_validation_seed_result',
            family=family,candidate_id=locked['families'][family]['candidate_id'],recoil_seed=seed,
            design=json.loads(output.read_text())['design'])
        audit.append(dict(family=family,seed=seed,atoms=len(end),integration_calls=0,
                          result_sha256=hashlib.sha256(output.read_bytes()).hexdigest()))
        print('PUBLISHED',family,seed,flush=True)
(backup/'recovery_receipt.json').write_text(json.dumps(dict(endpoint_key_fix='eligible_at_100ms -> eligible_at_50ms',
    original_runtime_unchanged=True,checkpoint_provenance_unchanged=True,results=audit),indent=2))
print('ALL SIX RESULTS VERIFIED; NO ATOMS REINTEGRATED',flush=True)
