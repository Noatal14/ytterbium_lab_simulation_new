def _matches_generated_zeeman_reference(reference, expected_path):
    """Production records basenames relative to its declared ensemble directory.

    Only an exact basename may use that directory. References containing path
    components retain the existing strict resolved-path comparison.
    """
    if not isinstance(reference, str) or not reference:
        return False
    recorded = Path(reference)
    expected = Path(expected_path)
    if reference == expected.name:
        return (expected.parent / recorded).resolve() == expected.resolve()
    return recorded.resolve() == expected.resolve()

def _collect_final_validation_inputs(root, manifest):
    stage = manifest["stages"]["final_validation_input_generation"]
    states_dir = root / "final_validation_inputs" / "after_2d_mot"
    zeeman_dir = root / "final_validation_inputs" / "after_zeeman"
    replicate_dir = root / "final_validation_inputs" / "mot_2d_records" / "replicates"
    expected_zeeman_names = {
        f"production_zeeman_n50000_dt40us_seed{seed}{suffix}"
        for seed in FINAL_VALIDATION_ZEEMAN_SEEDS
        for suffix in (".npy", ".json")
    }
    expected_state_names = {
        f"mot_2d_survivors_zeeman_seed{zseed}_mot_seed{mseed}{suffix}"
        for zseed, mseed in zip(
            FINAL_VALIDATION_ZEEMAN_SEEDS, FINAL_VALIDATION_MOT_SEEDS
        )
        for suffix in (".npy", ".json")
    }
    expected_replicates = {
        f"zeeman_seed{seed}.json" for seed in FINAL_VALIDATION_ZEEMAN_SEEDS
    }
    if (
        {path.name for path in zeeman_dir.iterdir() if path.is_file()}
        != expected_zeeman_names
        or {path.name for path in states_dir.iterdir() if path.is_file()}
        != expected_state_names
        or {path.name for path in replicate_dir.iterdir() if path.is_file()}
        != expected_replicates
    ):
        raise RuntimeError(
            "Final-validation generation registry is incomplete or contaminated."
        )
    expected_params = manifest["upstream_2d_campaign"]["expected_survivor_parameters"]
    ensembles = []
    for zseed, mseed in zip(FINAL_VALIDATION_ZEEMAN_SEEDS, FINAL_VALIDATION_MOT_SEEDS):
        zeeman_path = (
            root
            / "final_validation_inputs"
            / "after_zeeman"
            / (f"production_zeeman_n50000_dt40us_seed{zseed}.npy")
        )
        zeeman_metadata_path = zeeman_path.with_suffix(".json")
        if not zeeman_path.is_file() or not zeeman_metadata_path.is_file():
            raise FileNotFoundError(f"Missing new Zeeman ensemble: {zeeman_path}")
        zeeman_metadata = json.loads(zeeman_metadata_path.read_text(encoding="utf-8"))
        if (
            zeeman_metadata.get("parameters", {}).get("seed") != zseed
            or zeeman_metadata.get("parameters", {}).get(
                "resolved_zeeman_magnet_profile"
            )
            != manifest["upstream_2d_campaign"]["expected_survivor_design"][
                "zeeman_profile"
            ]
            or zeeman_metadata.get("output_sha256") != _sha256(zeeman_path)
            or zeeman_metadata.get("laboratory_spec_version") != LABORATORY_SPEC_VERSION
            or zeeman_metadata.get("laboratory_spec_sha256") != LABORATORY_SPEC_SHA256
            or zeeman_metadata.get("zeeman_profile_sha256")
            != CANONICAL_ZEEMAN_PROFILE_SHA256
        ):
            raise ValueError(f"Invalid new Zeeman ensemble: {zeeman_path}")
        path = states_dir / f"mot_2d_survivors_zeeman_seed{zseed}_mot_seed{mseed}.npy"
        metadata_path = path.with_suffix(".json")
        if not path.is_file() or not metadata_path.is_file():
            raise FileNotFoundError(f"Missing new sealed survivor ensemble: {path}")
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        replicate_path = replicate_dir / f"zeeman_seed{zseed}.json"
        replicate = json.loads(replicate_path.read_text(encoding="utf-8"))
        values = np.load(path, mmap_mode="r")
        design = metadata.get("design", {})
        expected_design = {
            "dt_s": MOT_2D_SIM_CONFIG["dt_s"],
            "stochastic_solver": manifest["upstream_2d_campaign"][
                "expected_survivor_design"
            ]["stochastic_solver"],
            "uses_all_available_particles": True,
            "npools": 200,
            "ensemble_dir": str(zeeman_dir),
            "zeeman_profile": manifest["upstream_2d_campaign"][
                "expected_survivor_design"
            ]["zeeman_profile"],
            "git_commit": manifest["provenance"]["git_commit"],
            "laboratory_spec_version": LABORATORY_SPEC_VERSION,
            "laboratory_spec_sha256": LABORATORY_SPEC_SHA256,
            "zeeman_profile_sha256": CANONICAL_ZEEMAN_PROFILE_SHA256,
        }
        if (
            metadata.get("kind") != "mot_2d_final_survivor_ensemble"
            or metadata.get("zeeman_seed") != zseed
            or metadata.get("mot_seed") != mseed
            or metadata.get("parameters") != expected_params
            or design != expected_design
            or not _matches_generated_zeeman_reference(metadata.get("source_zeeman_ensemble"), zeeman_path)
            or replicate.get("kind") != "mot_2d_final_production_replicate"
            or replicate.get("parameters") != expected_params
            or replicate.get("design") != expected_design
            or replicate.get("replicate", {}).get("zeeman_seed") != zseed
            or replicate.get("replicate", {}).get("mot_seed") != mseed
            or not _matches_generated_zeeman_reference(replicate.get("replicate", {}).get("ensemble_file"), zeeman_path)
            or replicate.get("replicate", {}).get("captured") != len(values)
            or list(values.shape) != metadata.get("shape")
            or metadata.get("output_sha256") != _sha256(path)
            or len(values) == 0
            or not np.all(np.isfinite(values))
        ):
            raise ValueError(f"Invalid new sealed survivor ensemble: {path}")
        ensembles.append(
            {
            "zeeman_seed": zseed,
            "mot_seed": mseed,
            "path": str(path.resolve()),
            "metadata_path": str(metadata_path.resolve()),
            "sha256": _sha256(path),
            "metadata_sha256": _sha256(metadata_path),
            "replicate_path": str(replicate_path.resolve()),
            "replicate_sha256": _sha256(replicate_path),
            "zeeman_path": str(zeeman_path.resolve()),
            "zeeman_sha256": _sha256(zeeman_path),
            "zeeman_metadata_path": str(zeeman_metadata_path.resolve()),
            "zeeman_metadata_sha256": _sha256(zeeman_metadata_path),
            "shape": list(values.shape),
            "n_survivors": len(values),
            }
        )
    return ensembles
