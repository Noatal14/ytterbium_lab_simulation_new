def _build_3d_simulation_config(_3d_mot_config, gravity_enabled, magnetic_gradient_G_cm=None):
    """Shared physical environment for full trajectories and compact validation."""
    resolved_gradient_G_cm = (
        _3d_mot_config.get(
            "magnetic_gradient_G_cm", MOT_3D_MAGNETIC_FIELD_GRADIENT_G_CM
        )
        if magnetic_gradient_G_cm is None
        else magnetic_gradient_G_cm
    )
    _, simulation_config = build_base_config(
        atom_species="Yb171",
        include_zeeman=True,
        include_2d_mot=True,
        include_3dmot=True,
        gravity_enabled=gravity_enabled,
        magnet_radius=MOT_2D_MAGNET_RADIUS_M,
        _2d_mot_config=MOT_2D_LASER_CONFIG,
        zeeman_config=ZEEMAN_LASER_CONFIG,
        zones=get_entire_apparatus_zone(),
        _3d_mot_config=_3d_mot_config,
        _3d_mot_gradient_G_cm=resolved_gradient_G_cm,
    )
    return simulation_config
