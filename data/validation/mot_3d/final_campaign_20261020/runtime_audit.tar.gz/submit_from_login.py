"""PBS submission gate: requires a successful full-grid runtime preflight.

Three fixed resource lanes, immutable checkpoint identities, bounded retries.
Scientific acceptance/precision decisions are never made by this scheduler.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess


PROJECT=Path('/home/tal.noa/ytterbium_lab_simulation_new')
RUNTIME=Path('/home/tal.noa/ytterbium_validation_runtime_5us_50ms_20261019_v1')
CAMPAIGN=Path('data/optimization/mot_3d/mot_3d_s0_1p3_search10us_20261012_v1')
FAMILIES=('angled_donut','single_pass')
SEEDS=(44001,44002,44003)
HOSTS=('n152','n177','n172')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def header(name,host,*,workers=200,memory='64gb',walltime='12:00:00'):
    return f'''#!/bin/bash
#PBS -N {name}
#PBS -q zeus_combined_q
#PBS -l select=1:ncpus={workers}:mem={memory}:host={host}
#PBS -l walltime={walltime}
set -euo pipefail
cd {PROJECT}
source /home/tal.noa/venvs/atomsmltr/bin/activate
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MPLBACKEND=Agg
export MPLCONFIGDIR=/tmp/mot3d_validation_mpl_${{PBS_JOBID}}
mkdir -p "$MPLCONFIGDIR"
'''


def submit():
    receipt=RUNTIME/'runtime_receipt.json'
    preflight=CAMPAIGN/'diagnostics/runtime_preflight_5us_50ms_20261019_v1/preflight_pass.json'
    proof=json.loads(preflight.read_text())
    receipt_hash=digest(receipt)
    if not proof.get('passed') or proof.get('runtime_receipt_sha256')!=receipt_hash:
        raise RuntimeError('Preflight did not pass for this exact runtime')
    rows=proof['results']
    if {row['family'] for row in rows}!=set(FAMILIES) or len(rows)!=2:
        raise RuntimeError('Both geometries must pass preflight')
    if any(not all(row[key] for key in ('trajectory_parity','resume_verified','endpoint_parity'))
           or row['dt_s']!=5e-6 or row['t_max_s']!=.05 for row in rows):
        raise RuntimeError('Incomplete preflight checks')
    # Zeus/Linux reports ru_maxrss in KiB. This is a conservative linear
    # extrapolation, not a claim of measuring a full 200-process run.
    parent_rss=proof.get('peak_parent_rss')
    child_rss=proof.get('peak_child_rss')
    if not all(isinstance(value,(int,float)) and value>0 for value in (parent_rss,child_rss)):
        raise RuntimeError('Missing memory measurements from preflight')
    memory_estimate_bytes=int((parent_rss+200*child_rss)*1024)
    if memory_estimate_bytes > .8*64*1024**3:
        raise RuntimeError('Preflight memory extrapolation exceeds 80% of the reservation; inspect before submitting')
    for name,value in json.loads(receipt.read_text())['files'].items():
        if digest(RUNTIME/name)!=value:
            raise RuntimeError('Runtime overlay changed after preflight')
    manifest_path=CAMPAIGN/'validation_5us_50ms_manifest.json'
    manifest=json.loads(manifest_path.read_text())
    if manifest['stage']!='final_validation' or manifest['design']['production_dt_s']!=5e-6:
        raise RuntimeError('Campaign not ready for final validation')
    stage=manifest['stages']['final_validation']
    locked=Path(stage['locked_nominals'])
    inputs=Path(stage['input_manifest'])
    candidates=json.loads(locked.read_text())['families']
    if candidates['angled_donut']['candidate_id']!='angled_donut_finalist_03' or candidates['single_pass']['candidate_id']!='single_pass_finalist_01':
        raise RuntimeError('Locked winners changed')
    record_path=CAMPAIGN/'final_validation_5us_50ms_submission.json'
    record=dict(kind='mot_3d_checkpointed_validation_submission',stage='final_validation',
        status='submitting',baseline_commit=json.loads(receipt.read_text())['baseline_commit'],
        runtime_directory=str(RUNTIME),runtime_receipt_sha256=receipt_hash,
        preflight_sha256=digest(preflight),campaign_sha256=digest(manifest_path),
        input_manifest_sha256=digest(inputs),locked_nominals_sha256=digest(locked),
        scheduler_source_sha256=digest(__file__),
        max_concurrent_lanes=3,walltime_per_attempt_hours=12,soft_budget_hours=10,
        checkpoint_atoms=200,max_attempts_per_family_seed=3,
        conservative_memory_estimate_bytes=memory_estimate_bytes,
        official_endpoint_s=.05,secondary_endpoint_s=.03,dt_s=5e-6,
        no_automatic_scientific_completion=True,jobs=[],families={})
    if record_path.exists():
        previous_record=json.loads(record_path.read_text())
        if previous_record.get('status')!='partial_failure':
            raise FileExistsError('Submission already exists; refusing duplicate jobs')
        for key in ('baseline_commit','runtime_receipt_sha256','preflight_sha256',
                    'campaign_sha256','input_manifest_sha256','locked_nominals_sha256',
                    'dt_s','official_endpoint_s','checkpoint_atoms'):
            if previous_record.get(key)!=record.get(key):
                raise RuntimeError(f'Partial submission design differs: {key}')
        previous_record.setdefault('scheduler_repair_history',[]).append(
            previous_record['scheduler_source_sha256'])
        previous_record['scheduler_source_sha256']=record['scheduler_source_sha256']
        previous_record.setdefault('resolved_submission_errors',[]).append(previous_record.pop('error',None))
        record=previous_record
        record['status']='submitting'
    else:
        with record_path.open('x') as stream:
            json.dump(record,stream,indent=2)
    known={(row['family'],row['recoil_seed'],row['attempt']):row for row in record['jobs']}
    if len(known)!=len(record['jobs']):
        raise RuntimeError('Duplicate partial submission entries')
    def save():
        temp=record_path.with_suffix('.tmp')
        temp.write_text(json.dumps(record,indent=2))
        temp.replace(record_path)
    jobs=RUNTIME/'jobs'
    jobs.mkdir(exist_ok=True)
    def qsub(path,dependency=None):
        command=['qsub']
        if dependency:
            command+=['-W',f'depend={dependency}']
        command.append(str(path))
        result=subprocess.check_output(command,text=True).strip()
        if re.fullmatch(r'\d+(?:\[\])?\.zeus-master',result) is None:
            raise RuntimeError(f'qsub did not return a PBS job ID: {result!r}')
        return result
    try:
        last_jobs=[]
        for lane,(host,seed) in enumerate(zip(HOSTS,SEEDS)):
            previous=None
            for attempt in range(1,4):
                for family in FAMILIES:
                    script=jobs/f'{family}_{seed}_attempt{attempt}.pbs'
                    output=CAMPAIGN/'final_validation_5us_50ms'/family/f'seed_{seed}.json'
                    checkpoints=CAMPAIGN/'diagnostics/checkpoints_5us_50ms_v1'/family/f'seed_{seed}'
                    args=[str(RUNTIME/'entry.py'),'run','--family',family,'--recoil-seed',str(seed),
                        '--locked-nominals',str(locked),'--input-manifest',str(inputs),
                        '--campaign-manifest',str(manifest_path),'--output',str(output),
                        '--npools','200','--dt','5e-6','--t-max','0.05',
                        '--checkpoint-dir',str(checkpoints),'--checkpoint-chunk-size','200',
                        '--wall-budget-s',str(10*3600),'--capture-time-comparison-dir',
                        str(CAMPAIGN/'diagnostics/capture_time_comparison_30_50ms')]
                    script.write_text(header(f'm3dv_{lane}_{family[:2]}_r{attempt}',host)+
                        'python -u '+shlex.join(args)+'\n')
                    existing=known.get((family,seed,attempt))
                    if existing is not None:
                        if existing['host']!=host or existing['dependency']!=previous or existing['script_sha256']!=digest(script):
                            raise RuntimeError('Existing submitted job differs from current plan')
                        job=existing['job_id']
                        if re.fullmatch(r'\d+(?:\[\])?\.zeus-master',job) is None:
                            raise RuntimeError('Invalid previously submitted job ID')
                    else:
                        job=qsub(script,f'afterany:{previous}' if previous else None)
                        record['jobs'].append(dict(job_id=job,family=family,recoil_seed=seed,
                            attempt=attempt,host=host,dependency=previous,script_sha256=digest(script)))
                    previous=job
                    save()
            last_jobs.append(previous)
        merge_script=jobs/'merge_all.pbs'
        text=header('m3dv_merge','n172',workers=1,memory='8gb',walltime='02:00:00')
        for family in FAMILIES:
            root=CAMPAIGN/'final_validation_5us_50ms'/family
            args=[str(RUNTIME/'entry.py'),'merge','--family',family,'--input-root',str(root),
                '--locked-nominals',str(locked),'--input-manifest',str(inputs),
                '--campaign-manifest',str(manifest_path),'--dt','5e-6',
                '--output',str(root/'final_validation_summary.json'),
                '--bootstrap-replicates','20000','--bootstrap-seed','92001']
            text+='python -u '+shlex.join(args)+'\n'
            args=[str(RUNTIME/'entry.py'),'diagnostic-merge',
                str(CAMPAIGN/'diagnostics/capture_time_comparison_30_50ms'),family,
                str(CAMPAIGN/'diagnostics'/f'capture_time_30_50ms_{family}.json')]
            text+='python -u '+shlex.join(args)+'\n'
        merge_script.write_text(text)
        merge_job=qsub(merge_script,'afterany:'+':'.join(last_jobs))
        record['merge_job_id']=merge_job
        record['status']='submitted'
        for family in FAMILIES:
            record['families'][family]=dict(jobs=[r['job_id'] for r in record['jobs'] if r['family']==family],merge_job_id=merge_job)
        save()
        print(json.dumps(record,indent=2),flush=True)
    except BaseException as error:
        record.update(status='partial_failure',error=f'{type(error).__name__}: {error}')
        save()
        raise


if __name__=='__main__':
    submit()
