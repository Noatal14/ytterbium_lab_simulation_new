"""Reduce each final-validation trajectory inside its own worker process.

The inherited hybrid RK4 integration and per-particle RNG streams are unchanged.
Only compact booleans cross the process boundary: the parent never retains all
N dense trajectories. Peak trajectory storage scales with workers, not atoms.
"""
from __future__ import annotations

import numpy as np

from simulations.mot_3d import (
    _build_3d_simulation_config, _configured_3d_solver, MOT_3D_CAPTURE_CONFIG, Geometry,
)
from studies.mot_3d.analysis.retention import instantaneous_capture_masks, inside_capture_masks
from studies.mot_3d.analysis.capture_time_comparison import extract_masks
from utils.RK4StHybridCustom import RK4StHybridCustom
from utils.simulation_helpers import generate_timepoints


class CompactValidationRK4(RK4StHybridCustom):
    """Identical integrator; discard the trajectory only after its metrics exist."""

    collect_capture_time_comparison = False

    def integrate(self, u0, t):
        trajectory = super().integrate(u0, t)
        capture = MOT_3D_CAPTURE_CONFIG
        eligible = instantaneous_capture_masks(
            [trajectory], t, Geometry.MOT_3D_CENTER_M,
            capture['capture_radius_m'], capture['maximum_final_speed_m_s'],
        )
        row = {'usable_at_end':bool(eligible[0,-1]), 'usable_ever':bool(eligible.any())}
        if self.collect_capture_time_comparison:
            inside = inside_capture_masks([trajectory],t,Geometry.MOT_3D_CENTER_M,capture['capture_radius_m'])
            masks = extract_masks(eligible,inside,t,np.array([0],dtype=np.int64))
            row['diagnostic'] = {key:bool(value[0]) for key,value in masks.items() if value.dtype == np.bool_}
        return row


def run_compact_validation(states, *, profile, seed, npools, dt, t_max,
                           collect_comparison=False, progress_callback=None,
                           trajectory_seed_sequences=None):
    """Integrate each atom once using the original global SeedSequence ordering."""
    if _configured_3d_solver() is not RK4StHybridCustom:
        raise ValueError('Compact validation only supports the pinned hybrid RK4 solver')
    states = np.asarray(states,dtype=float)
    if states.ndim != 2 or states.shape[1] != 6 or not np.isfinite(states).all():
        raise ValueError('Expected finite N x 6 sealed input states')
    if not np.isfinite(dt) or not np.isfinite(t_max) or dt <= 0 or t_max <= 0:
        raise ValueError('Invalid integration grid')
    times,_ = generate_timepoints(t_max,dt)
    sim = CompactValidationRK4(_build_3d_simulation_config(profile,True))
    sim.seed_idx = seed
    if trajectory_seed_sequences is not None:
        sim.trajectory_seed_sequences = trajectory_seed_sequences
    sim.rng = np.random.default_rng(seed)
    sim.collect_capture_time_comparison = bool(collect_comparison)
    sim.u0_list = [state.copy() for state in states]
    # One global run is important: resetting seeds on chunks would change atoms.
    options = dict(npools=npools,verbose=True)
    if progress_callback is not None:
        options['progress_callback'] = progress_callback
    rows = sim.run(times,**options)
    if len(rows) != len(states):
        raise ValueError('Compact outcome count differs from the sealed inputs')
    end = np.asarray([row['usable_at_end'] for row in rows],dtype=bool)
    ever = np.asarray([row['usable_ever'] for row in rows],dtype=bool)
    diagnostic = None
    if collect_comparison and rows:
        keys = tuple(rows[0]['diagnostic'])
        if any(tuple(row['diagnostic']) != keys for row in rows):
            raise ValueError('Inconsistent compact diagnostic fields')
        diagnostic = {key:np.asarray([row['diagnostic'][key] for row in rows],dtype=bool) for key in keys}
    return end,ever,diagnostic
