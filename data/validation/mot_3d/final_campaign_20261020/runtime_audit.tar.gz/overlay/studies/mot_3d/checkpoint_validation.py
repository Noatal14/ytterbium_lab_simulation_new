"""Restartable compact validation; chunks retain global per-atom RNG streams."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile
import time

import numpy as np

from studies.mot_3d.compact_validation import run_compact_validation


def run_checkpointed_validation(states, *, checkpoint_dir, chunk_size=200,
                               wall_budget_s=None, **kwargs):
    states = np.asarray(states, dtype=float)
    if states.ndim != 2 or states.shape[1] != 6 or not np.isfinite(states).all():
        raise ValueError('Expected finite N x 6 states')
    if not isinstance(chunk_size, int) or chunk_size <= 0:
        raise ValueError('Invalid chunk size')
    root = Path(checkpoint_dir)
    root.mkdir(parents=True, exist_ok=True)
    provenance = dict(seed=kwargs['seed'], dt=kwargs['dt'], t_max=kwargs['t_max'],
                      profile=kwargs['profile'], collect_comparison=kwargs.get('collect_comparison', False),
                      chunk_size=chunk_size, n=len(states),
                      states_sha256=hashlib.sha256(states.tobytes()).hexdigest(),
                      runtime_receipt_sha256=os.environ.get('MOT3D_RUNTIME_RECEIPT_SHA256'))
    fingerprint = hashlib.sha256(json.dumps(provenance, sort_keys=True).encode()).hexdigest()
    manifest = root / 'checkpoint_design.json'
    normalized = json.loads(json.dumps(provenance))
    if manifest.exists():
        if json.loads(manifest.read_text()) != normalized:
            raise ValueError('Checkpoint design changed; refusing reuse')
    else:
        with manifest.open('x') as stream:
            json.dump(normalized, stream, sort_keys=True)
    sequences = np.random.SeedSequence(kwargs['seed']).spawn(len(states))
    end_parts, ever_parts, flag_parts = [], [], []
    started = time.monotonic()
    for start in range(0, len(states), chunk_size):
        stop = min(start + chunk_size, len(states))
        destination = root / f'particles_{start:06d}_{stop:06d}.npz'
        if not destination.exists():
            if wall_budget_s is not None and time.monotonic() - started > wall_budget_s:
                raise TimeoutError('Wall budget reached at checkpoint boundary; resume same command')
            end, ever, flags = run_compact_validation(
                states[start:stop], trajectory_seed_sequences=sequences[start:stop], **kwargs)
            payload = dict(usable_at_end=end, usable_ever=ever,
                           fingerprint=np.array(fingerprint), start=np.array(start), stop=np.array(stop))
            payload.update({f'diagnostic_{key}': value for key, value in (flags or {}).items()})
            descriptor, temporary = tempfile.mkstemp(prefix='.chunk-', suffix='.npz', dir=root)
            os.close(descriptor)
            try:
                np.savez_compressed(temporary, **payload)
                with open(temporary, 'rb') as stream:
                    os.fsync(stream.fileno())
                os.replace(temporary, destination)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
        with np.load(destination, allow_pickle=False) as data:
            if str(data['fingerprint']) != fingerprint or int(data['start']) != start or int(data['stop']) != stop:
                raise ValueError('Checkpoint identity mismatch')
            end = data['usable_at_end'].copy()
            ever = data['usable_ever'].copy()
            flags = {key.removeprefix('diagnostic_'): data[key].copy()
                     for key in data.files if key.startswith('diagnostic_')}
            arrays = [end, ever, *flags.values()]
            if any(a.dtype != np.bool_ or a.shape != (stop-start,) for a in arrays):
                raise ValueError('Checkpoint boolean shape/dtype mismatch')
            if np.any(end & ~ever):
                raise ValueError('Invalid checkpoint capture relationship')
            if kwargs.get('collect_comparison', False):
                from studies.mot_3d.analysis.capture_time_comparison import extract_masks
                # The flag registry is fixed by the same reducer used for fresh chunks.
                expected_flags = set(extract_masks(np.zeros((1,2),dtype=bool),
                    np.zeros((1,2),dtype=bool),np.array([.03,.05]),np.array([0]))) - {'ensemble_ids','particle_indices'}
                if set(flags) != expected_flags or not np.array_equal(flags['eligible_at_50ms'], end):
                    raise ValueError('Checkpoint diagnostic mismatch')
            elif flags:
                raise ValueError('Unexpected checkpoint diagnostics')
        print(f'Checkpoint verified: {stop}/{len(states)} particles', flush=True)
        end_parts.append(end)
        ever_parts.append(ever)
        flag_parts.append(flags)
    if not end_parts:
        return np.array([],dtype=bool), np.array([],dtype=bool), None
    diagnostics = ({key: np.concatenate([row[key] for row in flag_parts])
                    for key in flag_parts[0]} if flag_parts[0] else None)
    return np.concatenate(end_parts), np.concatenate(ever_parts), diagnostics
