"""Paired 30/50-ms diagnostics; never changes the official 50-ms endpoint.

Predeclared descriptive tolerances: 0.25 percentage points for the net change
and for identity disagreement. Decisions apply only to the two tested locked
profiles. Bootstrap intervals cannot bound unseen rare events in constant data;
human scientific review remains mandatory, even when the observed checks pass.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import tempfile

import numpy as np

from studies.mot_3d.integrity import sha256
from utils.file_helpers import save_file_json

EARLY_S = .03
FINAL_S = .05
MAX_NET_CHANGE = .0025
MAX_DISAGREEMENT = .0025
METRICS = ('net_late_minus_early', 'lost_after_30ms', 'captured_after_30ms', 'identity_disagreement')
EXPECTED_SEEDS = (44001, 44002, 44003)


def extract_masks(eligible, inside, time_points, ensemble_ids):
    eligible, inside = np.asarray(eligible), np.asarray(inside)
    times, ids = np.asarray(time_points), np.asarray(ensemble_ids)
    if (eligible.dtype != np.bool_ or inside.dtype != np.bool_
            or eligible.ndim != 2 or inside.shape != eligible.shape
            or times.ndim != 1 or eligible.shape != (len(ids), len(times))
            or len(ids) == 0 or ids.dtype.kind not in 'iu' or np.any(ids < 0)
            or not np.isfinite(times).all() or np.any(np.diff(times) <= 0)):
        raise ValueError('Invalid time-resolved masks or ensemble identities')
    # Avoid allocating a full extra N x time-grid array at the production dt.
    for start in range(0,len(ids),128):
        if np.any(eligible[start:start+128] & ~inside[start:start+128]):
            raise ValueError('Eligibility cannot be true outside the capture sphere')
    indices = []
    for endpoint in (EARLY_S, FINAL_S):
        matched = np.flatnonzero(np.isclose(times, endpoint, rtol=0, atol=1e-12))
        if len(matched) != 1:
            raise ValueError(f'Missing exact endpoint {endpoint:g} s; do not interpolate capture flags')
        indices.append(int(matched[0]))
    first, last = indices
    if last != len(times)-1:
        raise ValueError('Diagnostic requires a 50-ms final endpoint')
    early, final = eligible[:, first], eligible[:, last]
    return {
        'eligible_at_30ms': early.copy(), 'eligible_at_50ms': final.copy(),
        'lost_after_30ms': early & ~final,
        'captured_after_30ms': ~early & final,
        'temporarily_ineligible_after_30ms': early & ~np.all(eligible[:, first:last+1], axis=1),
        'left_capture_region_after_30ms': early & ~np.all(inside[:, first:last+1], axis=1),
        'ensemble_ids': ids.copy(),
        'particle_indices': np.arange(len(ids), dtype=np.int64),
    }


def write_seed(directory, *, eligible, inside, time_points, ensemble_ids,
               family, candidate_id, recoil_seed, design, capture_config,
               canonical_archive):
    """Publish a compact sidecar outside the canonical final-result directory."""
    arrays = extract_masks(eligible, inside, time_points, ensemble_ids)
    return write_seed_arrays(directory,arrays=arrays,family=family,candidate_id=candidate_id,
                             recoil_seed=recoil_seed,design=design,capture_config=capture_config,
                             canonical_archive=canonical_archive)


def write_seed_arrays(directory, *, arrays, family, candidate_id, recoil_seed,
                      design, capture_config, canonical_archive):
    """Publish already reduced worker flags, without constructing N x time masks."""
    if family not in ('angled_donut', 'single_pass') or recoil_seed not in EXPECTED_SEEDS:
        raise ValueError('Unexpected final-validation family or recoil seed')
    ensemble_ids = arrays['ensemble_ids']
    n = len(ensemble_ids)
    flags = ('eligible_at_30ms','eligible_at_50ms','lost_after_30ms','captured_after_30ms',
             'temporarily_ineligible_after_30ms','left_capture_region_after_30ms')
    if (set(arrays) != {*flags,'ensemble_ids','particle_indices'} or n == 0
            or any(np.asarray(arrays[k]).shape != (n,) or np.asarray(arrays[k]).dtype != np.bool_ for k in flags)
            or not np.array_equal(arrays['particle_indices'],np.arange(n))):
        raise ValueError('Invalid reduced diagnostic flags')
    root = Path(directory)/family
    root.mkdir(parents=True, exist_ok=True)
    archive, metadata = root/f'seed_{recoil_seed}.npz', root/f'seed_{recoil_seed}.json'
    record = {
        'kind': 'mot_3d_paired_capture_time_seed', 'family': family,
        'candidate_id': candidate_id, 'recoil_seed': recoil_seed,
        'design': design, 'capture_config': dict(capture_config),
        'early_time_s': EARLY_S, 'final_time_s': FINAL_S,
        'canonical_outcomes_sha256': sha256(canonical_archive),
        'canonical_outcomes_path': str(Path(canonical_archive).resolve()),
        'input_particle_count': len(ensemble_ids),
        'counts': {key:int(value.sum()) for key,value in arrays.items()
                   if value.dtype == np.bool_},
    }
    record = json.loads(json.dumps(record))
    if metadata.exists():
        old = json.loads(metadata.read_text())
        if old != dict(record, outcomes_sha256=sha256(archive)):
            raise ValueError('Existing time diagnostic has incompatible provenance')
        with np.load(archive, allow_pickle=False) as data:
            if set(data.files) != set(arrays) or any(not np.array_equal(data[k],v) for k,v in arrays.items()):
                raise ValueError('Existing time diagnostic has incompatible atom outcomes')
        return
    if archive.exists():
        raise ValueError('Partial time diagnostic exists; inspect before retrying')
    fd, temporary = tempfile.mkstemp(prefix='.capture_time_', suffix='.npz', dir=root)
    os.close(fd)
    try:
        np.savez_compressed(temporary, **arrays)
        with open(temporary, 'rb') as stream:
            os.fsync(stream.fileno())
        os.link(temporary, archive)  # Exclusive publication; never replace a result.
    finally:
        os.unlink(temporary)
    save_file_json(metadata, dict(record, outcomes_sha256=sha256(archive)))


def read_seed(directory, family, recoil_seed):
    root = Path(directory)/family
    record = json.loads((root/f'seed_{recoil_seed}.json').read_text())
    archive = root/f'seed_{recoil_seed}.npz'
    if (record['kind'] != 'mot_3d_paired_capture_time_seed' or record['family'] != family
            or record['recoil_seed'] != recoil_seed or record['outcomes_sha256'] != sha256(archive)
            or record['early_time_s'] != EARLY_S or record['final_time_s'] != FINAL_S
            or sha256(record['canonical_outcomes_path']) != record['canonical_outcomes_sha256']):
        raise ValueError('Diagnostic identity or archive hash mismatch')
    with np.load(archive, allow_pickle=False) as data:
        arrays = {key:data[key].copy() for key in data.files}
    flags = ('eligible_at_30ms', 'eligible_at_50ms', 'lost_after_30ms', 'captured_after_30ms',
             'temporarily_ineligible_after_30ms', 'left_capture_region_after_30ms')
    if set(arrays) != {*flags,'particle_indices','ensemble_ids'}:
        raise ValueError('Invalid diagnostic array registry')
    n = record['input_particle_count']
    if (n <= 0 or any(arrays[k].shape != (n,) or arrays[k].dtype != np.bool_ for k in flags)
            or arrays['ensemble_ids'].shape != (n,) or arrays['ensemble_ids'].dtype.kind not in 'iu'
            or np.any(arrays['ensemble_ids'] < 0)
            or not np.array_equal(arrays['particle_indices'], np.arange(n))
            or record['counts'] != {k:int(arrays[k].sum()) for k in flags}):
        raise ValueError('Invalid diagnostic arrays or counts')
    early, final = arrays['eligible_at_30ms'], arrays['eligible_at_50ms']
    if (not np.array_equal(arrays['lost_after_30ms'],early & ~final)
            or not np.array_equal(arrays['captured_after_30ms'],~early & final)
            or np.any(arrays['temporarily_ineligible_after_30ms'] & ~early)
            or np.any(arrays['left_capture_region_after_30ms'] & ~arrays['temporarily_ineligible_after_30ms'])
            or np.any(arrays['lost_after_30ms'] & ~arrays['temporarily_ineligible_after_30ms'])):
        raise ValueError('Inconsistent paired diagnostic outcomes')
    with np.load(record['canonical_outcomes_path'],allow_pickle=False) as canonical:
        if (not np.array_equal(canonical['usable_at_end'],final)
                or not np.array_equal(canonical['ensemble_ids'],arrays['ensemble_ids'])):
            raise ValueError('Diagnostic differs from the canonical 50-ms endpoint')
    canonical_record = json.loads(Path(record['canonical_outcomes_path']).with_suffix('.json').read_text())
    expected = {
        'kind':'mot_3d_sealed_final_validation_seed_result', 'family':family,
        'candidate_id':record['candidate_id'], 'recoil_seed':recoil_seed,
        'input_particle_count':n, 'design':record['design'],
        'outcomes_sha256':record['canonical_outcomes_sha256'],
        'usable_at_end_count':int(final.sum()),
    }
    if any(canonical_record.get(key) != value for key,value in expected.items()):
        raise ValueError('Diagnostic provenance differs from the canonical seed result')
    return record,arrays


def paired_summary(early, final, ensemble_ids, *, replicates=10000, seed=93001):
    """Crossed ensemble/recoil/particle bootstrap with shared paired identities.

Joint outcome categories compact the particles without changing the empirical
resampling distribution, including their cross-recoil correlations.
"""
    early, final, ids = np.asarray(early), np.asarray(final), np.asarray(ensemble_ids)
    if (early.dtype != np.bool_ or final.dtype != np.bool_ or early.ndim != 2
            or early.shape != final.shape or early.shape[1] != len(ids)
            or not len(ids) or ids.dtype.kind not in 'iu' or np.any(ids < 0)
            or not 1 <= early.shape[0] <= 3 or replicates < 100):
        raise ValueError('Invalid paired bootstrap inputs')
    losses, gains = early & ~final, ~early & final
    features = np.stack([final.astype(np.int8)-early, losses, gains, early ^ final], axis=-1)
    observed = features.mean(axis=(0,1))
    recoil_count = len(early)
    codes = np.sum(np.concatenate([early, final], axis=0).T.astype(np.int64)
                   * (1 << np.arange(2*recoil_count)), axis=1)
    groups = []
    for group in np.unique(ids):
        members = np.flatnonzero(ids == group)
        _, unique_indices, counts = np.unique(codes[members], return_index=True, return_counts=True)
        groups.append((len(members), counts/counts.sum(), features[:, members[unique_indices], :]))
    rng = np.random.default_rng(seed)
    draws = np.empty((replicates,len(METRICS)))
    for i in range(replicates):
        recoils = rng.integers(0, recoil_count, recoil_count)
        selected_groups = rng.integers(0, len(groups), len(groups))
        numerator, denominator = np.zeros(len(METRICS)), 0
        for group in selected_groups:
            size, probabilities, values = groups[group]
            counts = rng.multinomial(size, probabilities)
            numerator += counts @ values[recoils].sum(axis=0)
            denominator += size*recoil_count
        draws[i] = numerator/denominator
    # Bonferroni across four diagnostic metrics and both tested families.
    tail = .05/(2*len(METRICS)*2)
    intervals = np.quantile(draws,[tail,1-tail],axis=0).T
    net_ok = intervals[0,0] >= -MAX_NET_CHANGE and intervals[0,1] <= MAX_NET_CHANGE
    disagreement_ok = intervals[3,1] <= MAX_DISAGREEMENT
    return {
        'kind': 'mot_3d_paired_capture_time_summary',
        'particle_count': len(ids), 'ensemble_count': len(groups), 'recoil_seed_count': recoil_count,
        'early_time_s': EARLY_S, 'final_time_s': FINAL_S,
        'mean_capture_fraction_at_30ms': float(early.mean()),
        'mean_capture_fraction_at_50ms': float(final.mean()),
        'metrics': {name:{'fraction':float(observed[j]), 'interval':intervals[j].tolist(),
                          'constant_bootstrap':bool(np.all(draws[:,j] == draws[0,j]))}
                    for j,name in enumerate(METRICS)},
        'tolerances_fraction': {'net_change':MAX_NET_CHANGE, 'identity_disagreement':MAX_DISAGREEMENT},
        'bootstrap': {'method':'crossed paired ensemble/recoil/within-ensemble particle resampling',
                      'replicates':replicates, 'seed':seed,
                      'familywise_confidence':.95, 'bonferroni_metrics_across_two_families':8},
        'supports_30ms_in_observed_data': bool(net_ok and disagreement_ok),
        'automatic_campaign_change': False, 'requires_scientific_review': True,
        'scope':'Only the tested locked profiles and input distribution; not arbitrary optimization trials',
        'warning':'Constant bootstrap draws do not give an upper bound on unseen rare escape events. '
                  'The official final-validation endpoint remains 100 ms.',
    }


def merge(directory, family, output, *, replicates=10000, seed=93001):
    root = Path(directory)/family
    records, arrays = [], []
    expected = {f'seed_{s}{ext}' for s in EXPECTED_SEEDS for ext in ('.json','.npz')}
    if {p.name for p in root.iterdir() if p.is_file()} != expected:
        raise ValueError('Incomplete or contaminated diagnostic seed registry')
    for recoil in EXPECTED_SEEDS:
        record,data = read_seed(directory,family,recoil)
        arrays.append(data)
        records.append(record)
    first = records[0]
    for record, data in zip(records, arrays):
        base = {k:v for k,v in record['design'].items() if k != 'recoil_seed'}
        reference = {k:v for k,v in first['design'].items() if k != 'recoil_seed'}
        if (base != reference or record['candidate_id'] != first['candidate_id']
                or record['capture_config'] != first['capture_config']
                or not np.array_equal(data['ensemble_ids'], arrays[0]['ensemble_ids'])
                or not np.array_equal(data['particle_indices'], np.arange(record['input_particle_count']))):
            raise ValueError('Unpaired diagnostic input ordering or design')
    summary = paired_summary(np.stack([d['eligible_at_30ms'] for d in arrays]),
                             np.stack([d['eligible_at_50ms'] for d in arrays]),
                             arrays[0]['ensemble_ids'], replicates=replicates, seed=seed)
    summary.update(family=family, candidate_id=first['candidate_id'],
                   source_diagnostic_hashes={f'seed_{s}.json':sha256(root/f'seed_{s}.json') for s in EXPECTED_SEEDS})
    if Path(output).resolve().parent == root.resolve():
        raise ValueError('Write the summary outside the per-seed diagnostic registry')
    save_file_json(output,summary)
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root',required=True)
    parser.add_argument('--family',choices=('angled_donut','single_pass'),required=True)
    parser.add_argument('--output',required=True)
    parser.add_argument('--bootstrap-replicates',type=int,default=10000)
    args=parser.parse_args()
    merge(args.input_root,args.family,args.output,replicates=args.bootstrap_replicates)
