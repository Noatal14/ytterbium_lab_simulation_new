"""Audited overlay over an unchanged pinned checkout; no implicit code migration."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


RUNTIME = Path(__file__).resolve().parent
receipt_path = RUNTIME / 'runtime_receipt.json'
receipt = json.loads(receipt_path.read_text())
for name, expected in receipt['files'].items():
    if hashlib.sha256((RUNTIME/name).read_bytes()).hexdigest() != expected:
        raise RuntimeError(f'Runtime file changed: {name}')
BASE = RUNTIME / 'base'
revision = subprocess.check_output(['git','-C',str(BASE),'rev-parse','HEAD'],text=True).strip()
if revision != receipt['baseline_commit']:
    raise RuntimeError('Runtime baseline revision changed')
dirty = subprocess.check_output(['git','-C',str(BASE),'diff','--name-only','HEAD'],text=True)
if dirty.strip():
    raise RuntimeError('Pinned runtime baseline must remain unchanged')
sys.path[:0] = [str(BASE),str(BASE/'atomsmltr/src')]
import studies.mot_3d
import studies.mot_3d.analysis
studies.mot_3d.__path__.insert(0,str(RUNTIME/'overlay/studies/mot_3d'))
studies.mot_3d.analysis.__path__.insert(0,str(RUNTIME/'overlay/studies/mot_3d/analysis'))
import simulations.mot_3d as physical
import studies.mot_3d_campaign as campaign
# Only add the extracted identical environment builder. The original dynamics,
# simulator, force and recoil implementation stay loaded from the pinned tree.
exec(compile((RUNTIME/'environment_helper.py').read_text(),str(RUNTIME/'environment_helper.py'),'exec'),physical.__dict__)
# Exact-basename resolution repair; every other input check remains unchanged.
exec(compile((RUNTIME/'campaign_path_fix.py').read_text(),str(RUNTIME/'campaign_path_fix.py'),'exec'),campaign.__dict__)
os.environ['MOT3D_RUNTIME_RECEIPT_SHA256'] = hashlib.sha256(receipt_path.read_bytes()).hexdigest()


def preflight(args):
    import numpy as np
    from studies.mot_3d.checkpoint_validation import run_checkpointed_validation
    from studies.mot_3d.analysis.retention import instantaneous_capture_masks
    from studies.mot_3d.analysis.capture_time_comparison import extract_masks
    from utils.simulation_helpers import generate_timepoints
    root = Path(args.campaign)
    manifest = json.loads((root/'validation_5us_50ms_manifest.json').read_text())
    from studies.mot_3d import final_validation
    sealed, sealed_ids, sealed_manifest = final_validation.load_sealed_inputs(
        root/'final_validation_inputs/input_manifest.json',root/'validation_5us_50ms_manifest.json',
        root/'selection/locked_nominals.json')
    if len(sealed)!=sealed_manifest['total_survivors'] or len(sealed_ids)!=len(sealed):
        raise ValueError('Final runner input loader disagrees with sealed manifest')
    del sealed, sealed_ids
    locked = json.loads((root/'selection/locked_nominals.json').read_text())
    old_paths = [Path(row['path']) for rows in manifest['input_roles'].values() for row in rows]
    pool = np.concatenate([np.load(path) for path in old_paths])
    order = np.argsort(pool[:,5])
    ids = order[np.linspace(0,len(pool)-1,args.atoms,dtype=int)]
    states = pool[ids].copy()
    dt = manifest['design']['production_dt_s']
    destination = Path(args.output)
    destination.mkdir(parents=True,exist_ok=True)
    results=[]
    for family in ('angled_donut','single_pass'):
        profile = locked['families'][family]['resolved_profile']
        t,_ = generate_timepoints(20*dt,dt)
        full,_ = physical.mot_3d_simulation(states[:1].copy(),_3d_mot_config=profile,
            seed=99041,npools=0,dt=dt,t_max=20*dt)
        from studies.mot_3d import compact_validation
        original=compact_validation.instantaneous_capture_masks
        observed=[]
        def spy(rows,*a,**kw):
            observed.extend([row.y.copy() for row in rows])
            return original(rows,*a,**kw)
        compact_validation.instantaneous_capture_masks=spy
        try:
            compact_validation.run_compact_validation(states[:1].copy(),profile=profile,
                seed=99041,npools=0,dt=dt,t_max=20*dt)
        finally:
            compact_validation.instantaneous_capture_masks=original
        np.testing.assert_array_equal(full[0].y,observed[0])
        started=time.monotonic()
        options=dict(checkpoint_dir=destination/family,chunk_size=args.atoms,
            profile=profile,seed=99041,npools=args.npools,dt=dt,t_max=.05,
            collect_comparison=True)
        end,ever,flags=run_checkpointed_validation(states.copy(),**options)
        elapsed=time.monotonic()-started
        second=run_checkpointed_validation(states.copy(),**options)
        np.testing.assert_array_equal(end,second[0])
        assert len(flags['eligible_at_30ms'])==len(states)
        np.testing.assert_array_equal(end,flags['eligible_at_50ms'])
        # A real full-length trajectory validates the worker reducer at both times.
        full,_=physical.mot_3d_simulation(states[:1].copy(),_3d_mot_config=profile,
            seed=99041,npools=0,dt=dt,t_max=.05)
        times,_=generate_timepoints(.05,dt)
        masks=instantaneous_capture_masks(full,times,physical.Geometry.MOT_3D_CENTER_M,
            physical.MOT_3D_CAPTURE_CONFIG['capture_radius_m'],
            physical.MOT_3D_CAPTURE_CONFIG['maximum_final_speed_m_s'])
        assert bool(end[0])==bool(masks[0,-1])
        assert bool(flags['eligible_at_30ms'][0])==bool(masks[0,int(round(.03/dt))])
        results.append(dict(family=family,atoms=len(states),workers=args.npools,
            dt_s=dt,t_max_s=.05,elapsed_s=elapsed,trajectory_parity=True,
            resume_verified=True,endpoint_parity=True))
    import resource
    record=dict(kind='mot3d_runtime_preflight',passed=True,
        source='old selection ensembles only; no sealed validation outcomes inspected',
        runtime_receipt_sha256=os.environ['MOT3D_RUNTIME_RECEIPT_SHA256'],
        peak_parent_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        peak_child_rss=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
        results=results)
    with (destination/'preflight_pass.json').open('x') as stream:
        json.dump(record,stream,indent=2)
    print(json.dumps(record,indent=2),flush=True)


def main():
    mode=sys.argv[1]
    if mode=='preflight':
        parser=argparse.ArgumentParser()
        parser.add_argument('--campaign',required=True)
        parser.add_argument('--output',required=True)
        parser.add_argument('--atoms',type=int,default=4)
        parser.add_argument('--npools',type=int,default=4)
        preflight(parser.parse_args(sys.argv[2:]))
    elif mode in ('freeze','advance'):
        root=Path(sys.argv[2])
        if mode=='freeze':
            payload=campaign.freeze_final_validation_inputs(root)
            print('Frozen:',payload['total_survivors'],'atoms')
        else:
            campaign.advance_campaign(argparse.Namespace(campaign=str(root)))
    elif mode in ('run','merge'):
        from studies.mot_3d import final_validation
        args=final_validation.parse_args(sys.argv[1:])
        args.func(args)
    elif mode=='diagnostic-merge':
        from studies.mot_3d.analysis.capture_time_comparison import merge
        merge(sys.argv[2],sys.argv[3],sys.argv[4])
    else:
        raise ValueError('Unknown runtime command')


if __name__=='__main__':
    main()
